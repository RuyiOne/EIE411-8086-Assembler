$(document).ready(function() {
	
	// OPEYEMI LADEJI
	//13CK015384
	//ELECT ELECT
	// 1303432
	
	
	
    // jQuery methods go here...
    var first = "";
    var second = "";
    var location = "";
    $("button").click(function() {
        first = $(".code").val().slice(0, 3);
        second = $(".code").val().slice(3, $(".code").val().length);
        location = $(".location").val();
        answer = "";
        if (first != "JNC") {
            $(".error").removeClass("hidden");
        } else {
            $(".error").addClass("hidden");
            console.log("s:" + second);
            console.log("l:" + location);
            var temp = parseInt(second) + parseInt(location);
            console.log(temp);
            answer = 255 - temp;
            alert("THE Binary AND HEXADECIMAL EQUIVALENTS Are: \n" + "Binary: " + dec2bin(answer) + "\n" + "HEX:" + answer.toString(16));

        }
    });
});



function dec2bin(dec) {
    return (parseInt(dec, 10) >>> 0).toString(2);
}